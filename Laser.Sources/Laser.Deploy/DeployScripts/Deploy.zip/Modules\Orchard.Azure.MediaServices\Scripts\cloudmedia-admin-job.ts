/// <reference path="typings/jquery.d.ts" />
