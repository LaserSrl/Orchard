/// <reference path="typings/jquery.d.ts" />
//# sourceMappingURL=cloudmedia-admin-job.js.map
