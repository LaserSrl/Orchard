Laser.Orchard.TemplateManagement
=================

An Orchard module enabling users to create  templates.