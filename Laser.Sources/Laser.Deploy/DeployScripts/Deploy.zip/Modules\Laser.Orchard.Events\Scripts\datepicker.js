﻿jQuery(function ($) {
    $('.date').datepicker({ showAnim: "", changeYear: true, changeMonth: true });
    //$('.date').attr( 'readOnly', 'true' );
});