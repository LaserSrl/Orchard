﻿// calling EditorFor(Part) -> will render a Publish button
// in this case we don't have a publish button, so we just hide it!

jQuery(function ($) {
    $('.save-button').hide();
}
);